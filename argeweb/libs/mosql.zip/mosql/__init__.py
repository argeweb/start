# -*- coding: utf-8 -*-

__author__ = 'Mosky <http://mosky.tw>'
__version__ = '0.10'

